#Create Serializers i.e Convert data to the json 
#with the help of serialization we can serialize or deserialize the data.
# we use djangoRestframework for serializers.

from rest_framework import serializers;
from .models import Products;

class ProductSerializer(serializers.HyperlinkedModelSerializer): 
    product_id=serializers.ReadOnlyField() #If you want to see the id with all fields. 
    class Meta:
        model=Products
        fields='__all__'  #Because I want to include all the fields of product model, we can also include only some of all products fields.
        
    
