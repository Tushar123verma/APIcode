from django.db import models

# Create your models here.

#Creating Models for the Products of Ecommerce shopping website.

class Products(models.Model):
    product_id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=50)
    description=models.TextField()
    price=models.DecimalField(max_digits=10, decimal_places=2)
    category=models.CharField(max_length=100,choices=(('Electronics','Electronics'),
                              ('clothing','clothing'),('shoes','shoes')))
    brand=models.CharField(max_length=50)
    stock_availability=models.IntegerField()
    