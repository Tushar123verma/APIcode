from django.contrib import admin
from django.urls import path,include
from .views import ProductView
from rest_framework import routers

Router=routers.DefaultRouter()
Router.register(r'products',ProductView)

urlpatterns = [
    
    path('',include(Router.urls))
    
]