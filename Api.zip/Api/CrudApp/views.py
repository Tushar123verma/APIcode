from django.shortcuts import render
from rest_framework import viewsets
from .models import Products
from .serializations import ProductSerializer

# Create your views here.

class ProductView(viewsets.ModelViewSet):  #ModelViewset class provide default Create,retrieve,Update,Delete function.
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    
